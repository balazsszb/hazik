import ApiService from "../services/apiService.js";
import LinkModel from "../models/linkModel.js";
import LinkLisView from "../views/LinkLisView.js";
import FormView from "../views/FormView.js"
import * as sea from "node:sea";
    export default class AppController{
    constructor() {
        this.api = new ApiService();
        this.model = new LinkModel();
        this.listview = new LinkLisView();
        this.formview = new FormView();
    }

    init(){
        document.getElementById('apiBase').textContent = this.api.base;
        this.formview.bind(async ({target, slug}) => {
            try {
                    await this.model.create(target, slug);
                    alert("Kész! Rövid link letrehozva.")
                } catch (e) {
                    alert(e.message)
                }
        });
        const search = document.getElementById('search')
        const sort = document.getElementById('sort')
        const dir = document.getElementById('dir')
        const refresh = document.getElementById('refresh')
        const reload = ()=> this.model.load();
        search.addEventListener("input", ()=>{
            this.model.filters.q = search.value; reload();
        })
        sort.addEventListener('change', ()=>{
            this.model.filters.sort = sort.value; reload();
        })
        dir.addEventListener('change', ()=>{
            this.model.filters.dir = dir.value; reload();
        });
        refresh.addEventListener('click', reload)
        this.model.onChange(({items}) => this.listview.render(items));
        this.listview.on('open', (r) => window.open(`${this.api.base}/r/${r.slug}`, "_blank"))
    }
}
# URL Shorty – Backend

Express API JSON perzisztenciával.

## Futtatás
```
npm install
npm start
# API alap: http://localhost:3000/api
```
